print("ZadJannahBot is alive!")
