
import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackContext, CallbackQueryHandler
import datetime

TOKEN = "YOUR_BOT_TOKEN_HERE"

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

async def start(update: Update, context: CallbackContext):
    keyboard = [[InlineKeyboardButton("اذكار الصباح", callback_data='morning'),
                 InlineKeyboardButton("اذكار المساء", callback_data='evening')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text('مرحبًا بك في ZadJannahBot، اختر من القائمة:', reply_markup=reply_markup)

async def button(update: Update, context: CallbackContext):
    query = update.callback_query
    await query.answer()
    if query.data == "morning":
        await query.edit_message_text("☀️ أذكار الصباح:
أصبحنا وأصبح الملك لله...")
    elif query.data == "evening":
        await query.edit_message_text("🌙 أذكار المساء:
أمسينا وأمسى الملك لله...")

if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button))
    app.run_polling()
